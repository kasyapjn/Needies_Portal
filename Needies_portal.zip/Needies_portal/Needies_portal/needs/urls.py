from django.urls import path
from . import views
app_name = 'needs'

urlpatterns = [
    path('',views.index,name='index'),
    path('emp_reg',views.emp_reg,name='emp_reg'),
    path('empyr_reg',views.empyr_reg,name='empyr_reg'),
    path('user_login',views.user_login,name='user_login'),
    path('employerjobpost',views.employerjobpost,name='employerjobpost'),
    path('employeejobsearch', views.employeejobsearch, name='employeejobsearch'),
    path('user_logout',views.user_logout,name='user_logout'),
    path('adminhome',views.adminhome,name='adminhome'),
    path('browsejobs',views.browsejobs,name='browsejobs'),
    path('candidates', views.candidates, name='candidates'),
    path('application/<int:id>', views.application, name='application'),
    path('contact', views.contact, name='contact'),
    path('short_list/<int:id>', views.short_list, name='short_list'),
    path('listed', views.listed, name='listed'),
    path('employer_req', views.employer_req,name='employer_req'),


    path('payment_check', views.payment_check, name='payment_check'),
    path('payment', views.payment, name='payment'),
    path('fee_paid/<u>/', views.fee_paid, name='fee_paid'),
    path('admincandview',views.admincandview,name='admincandview'),
    path('empyr_req_details/<int:id>', views.empyr_req_details, name='empyr_req_details'),
    path('empyr_req_approve/<int:id>', views.empyr_req_approve, name='empyr_req_approve')

    # path('search', views.search, name='search'),


]