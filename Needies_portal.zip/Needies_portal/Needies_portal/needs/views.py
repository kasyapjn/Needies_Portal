import razorpay
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from django.contrib import messages
from dateutil.relativedelta import relativedelta
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from .models import CustomUser, Job, Category, Applicants, Payment


# Create your views here.
def index(request):
    job = Job.objects.all()
    cat = Category.objects.all()
    return render(request,'index.html',{'job':job,'cat':cat})


def empyr_reg(request):
    return render(request,'empyr_reg.html')


def emp_reg(request):
    return render(request,'emp_reg.html')


def browsejobs(request):
    job = Job.objects.all()
    return render(request,'browsejobs.html',{'job':job})


def candidates(request):
    user = request.user
    date = user.empyr_payment_date
    if date:
        new_date = date + relativedelta(months=1)
        today = timezone.now().date()
        # new_date = '2024-10-22' #test
        # today = '2024-10-22'

        if new_date <= today:
            user.empyr_payment_status = False
            user.empyr_payment_date = '2024-01-01'
            user.save()
    if user.is_employer:
        # Filter the applicants based on the conditions
        applicants = Applicants.objects.filter(shortlist=False, job__user=user)

        # Pass the filtered applicants to the template
        return render(request, 'candidates.html', {'applicants': applicants})

    # In case the user is not an employer, handle accordingly (e.g., return an empty list or redirect)
    return render(request, 'candidates.html', {'applicants': []})


def short_list(request,id):
    a = Applicants.objects.get(id=id)
    a.shortlist = True
    a.save()
    return redirect('needs:candidates')


def listed(request):
    user = request.user
    if user.is_employer:
        # Filter the applicants based on the conditions
        applicants = Applicants.objects.filter(shortlist=True, job__user=user)

        # Pass the filtered applicants to the template
        return render(request, 'short_list.html', {'applicants': applicants})
    return render(request,'short_list.html')


def contact(request):
    return render(request,'contact.html')


# def search(request):
#     p = None
#     query = ""
#     if (request.method=="POST"):
#         query = request.POST['search']
#         if query:
#             p = Product.objects.filter(p_name__icontains=query)
#     return render(request,'search_products.html',{'query':query,'p':p})


def empyr_reg(request):
    if (request.method == "POST"):  # after submission
        u = request.POST['u']
        cin = request.POST['c']
        p = request.POST['p']
        cp = request.POST['cp']
        fn = request.POST['fn']
        ln = request.POST['ln']
        e = request.POST['e']
        if(cp==p):
            user = CustomUser.objects.create_user(username=u,cin=cin, password=p, first_name=fn, last_name=ln, email=e, is_employee=False, is_employer_reg=True)
            user.save()
            return redirect('needs:user_login')
    return render(request, 'empyr_reg.html')


def emp_reg(request):
    if (request.method == "POST"):  # after submission
        u = request.POST['u']
        p = request.POST['p']
        cp = request.POST['cp']
        fn = request.POST['fn']
        ln = request.POST['ln']
        e = request.POST['e']
        r = request.POST['r']
        pi =request.POST['pi']
        if(cp==p):
            user = CustomUser.objects.create_user(username=u, password=p, first_name=fn, last_name=ln, email=e, is_employee_image=pi, is_employee_resume=r)
            user.save()
            return redirect('needs:user_login')
    return render(request, 'emp_reg.html')


def user_login(request):
    if(request.method=="POST"):
        u=request.POST['u']
        p=request.POST['p']
        user=authenticate(username=u,password=p)
        if user and user.is_superuser==True:
            login(request,user)
            return redirect('needs:employer_req')

        elif user and user.is_employee==True:
            login(request, user)
            return redirect('needs:employeejobsearch')
        elif user and user.is_employer==True:
            login(request, user)
            return redirect('needs:candidates')

        else:
            messages.error(request,"Invalid User Credentails")

    return render(request, 'login.html')


def adminhome(request):
    return render(request,'adminhome.html')


def payment_check(request):
    user = request.user
    if user.empyr_payment_status == True:
        return redirect('needs:employerjobpost')
    else:
        return redirect('needs:payment')


def payment(request):
    user = request.user
    fee = 1000
    amount = int(fee)
    amount_payable = amount * 100

    client = razorpay.Client(auth=('rzp_test_4DuEprsTI3hLDn', 'vD0pR11FtGaldbHotwEakO44'))
    response_payment = client.order.create(dict(amount=amount_payable, currency="INR"))

    order_id = response_payment['id']
    order_status = response_payment['status']

    if order_status == 'created':
        p = Payment.objects.create(name=user.username, amount=amount_payable, order_id=order_id)
        p.save()
        response_payment['name'] = user.username
        print(response_payment)
        return render(request, 'payment.html', {'payment': response_payment})
    return render(request,'payment.html')


@csrf_exempt
def fee_paid(request,u):
    if not request.user.is_authenticated:
        user = CustomUser.objects.get(username=u)
        login(request, user)
    if (request.method == "POST"):
        response = request.POST
        print(response)
        param_dict = {
            'razorpay_order_id': response['razorpay_order_id'],
            'razorpay_payment_id': response['razorpay_payment_id'],
            'razorpay_signature': response['razorpay_signature']
        }
        client = razorpay.Client(auth=('rzp_test_4DuEprsTI3hLDn', 'vD0pR11FtGaldbHotwEakO44'))
        try:
            status = client.utility.verify_payment_signature(param_dict)

            print(param_dict)

            ord = Payment.objects.get(order_id=response['razorpay_order_id'])
            ord.razorpay_payment_id = response['razorpay_payment_id']
            ord.paid = True
            ord.save()

            u = request.user
            u.empyr_payment_status = True
            u.empyr_payment_date = timezone.now()
            u.save()

            return render(request,'fee_paid.html', {'status': True})

        except:
            return render(request,'fee_paid.html', {'status': False})
    return render(request,'fee_paid.html')



def employerjobpost(request):
    user = request.user
    c = Category.objects.all()
    if request.method == 'POST':
        title = request.POST['title']
        location = request.POST['location']
        job_type = request.POST['job_type']
        expirience = request.POST['expirience']
        category = request.POST['category']
        salary = request.POST['salary']
        description = request.POST['description']
        sdate = request.POST['sdate']
        company_details = request.POST['company_details']
        company_desc = request.POST['company_desc']
        website = request.POST['website']
        cat = Category.objects.get(id = category)
        j = Job.objects.create(user=user,title=title,expirience=expirience,description=description,location=location,
                               job_type=job_type,category=cat,salary=salary,company_name=company_details,
                               company_description=company_desc,url=website,last_date=sdate)
        j.save()
        return redirect('needs:candidates')
    return render(request,'empyr_jobpost.html',{'c':c})


def employeejobsearch(request):
    job = Job.objects.all()
    return render(request,'emp_jobsearch.html',{'job':job})


def user_logout(request):
    logout(request)
    return redirect('needs:index')


def application(request,id):
    user = request.user
    job =  Job.objects.get(id=id)
    try:
        already_exist = Applicants.objects.get(user=user,job=job)
        if already_exist:
            return redirect('needs:browsejobs')

    except:
        a = Applicants.objects.create(user=user, job=job)
        a.save()
        return redirect('needs:browsejobs')


def employer_req(request):
    req = CustomUser.objects.filter(is_employer_reg=True)
    return render(request,'employer_req.html',{'req':req})

def empyr_req_details(request,id):
    empyr = CustomUser.objects.get(id=id)
    return render(request,'empyr_req_details.html',{'empyr':empyr})

def admincandview(request):
    req = CustomUser.objects.all()
    return render(request,'admincandview.html',{'req':req})


def empyr_req_approve(request,id):
    empyr = CustomUser.objects.get(id=id)
    empyr.is_employer = True
    empyr.is_employer_reg = False
    empyr.save()
    return redirect('needs:employer_req')