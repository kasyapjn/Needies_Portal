from django.contrib.auth.models import AbstractUser
from django.db import models



# Create your models here.
class CustomUser(AbstractUser):
    is_employee = models.BooleanField(default=True)
    is_employer_reg = models.BooleanField(default=False)
    is_employer = models.BooleanField(default=False)
    cin = models.CharField(max_length=15,null=True,blank=True)
    is_employee_image = models.ImageField(upload_to='media/needs',null=True,blank=True)
    is_employee_resume = models.FileField(upload_to='media/needs',null=True,blank=True)
    empyr_payment_status = models.BooleanField(default=False)
    empyr_payment_date = models.DateField(blank=True,null=True,default='2024-01-01')







JOB_TYPE = (
    ('1', "Full time"),
    ('2', "Part time"),
    ('3', "Internship"),
)


class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Job(models.Model):
    user = models.ForeignKey(CustomUser, related_name='User', on_delete=models.CASCADE)
    title = models.CharField(max_length=300)
    expirience = models.CharField(max_length=50)
    description = models.TextField()
    location = models.CharField(max_length=300)
    job_type = models.CharField(choices=JOB_TYPE, max_length=1)
    category = models.ForeignKey(Category, related_name='Category', on_delete=models.CASCADE)
    salary = models.CharField(max_length=30, blank=True)
    company_name = models.CharField(max_length=300)
    company_description = models.TextField(blank=True, null=True)
    url = models.URLField(max_length=200)
    last_date = models.DateField()
    is_published = models.BooleanField(default=False)
    is_closed = models.BooleanField(default=False)


    def __str__(self):
        return self.title


class Applicants(models.Model):
    user = models.ForeignKey(CustomUser,on_delete=models.CASCADE)
    job = models.ForeignKey(Job,on_delete=models.CASCADE)
    shortlist = models.BooleanField(default=False)

    def __str__(self):
        return self.job.user.username


class Payment(models.Model):
    name = models.CharField(max_length=100)
    amount = models.CharField(max_length=100)
    order_id = models.CharField(max_length=100,blank=True)
    razorpay_payment_id = models.CharField(max_length=100,blank=True)
    paid = models.BooleanField(default=False)

    def __str__(self):
        return self.name